# Priority recheck: modular and integral spectral algebras of abelian Cayley graphs

Rechecked 14 October 2026, 19:29–20:05 UTC, after the release of v1.0.0
(doi:10.5281/zenodo.23376892). The first check (18:10–18:35 UTC the same day) is in
`repository/PRIORITY-CHECK.md`.

| Source | Search | Result |
|---|---|---|
| arXiv API | arXiv:2609.09222 | still v1 only (7 September 2026) |
| arXiv API | the seven searches of the first check, newest first | nothing new since 18:35 UTC |
| Semantic Scholar | papers citing arXiv:2609.09222 | none |
| Zenodo | `"adjacency algebra" Cayley`; `"spectral algebra" circulant`; the identifier 2609.09222 | only this deposit (doi:10.5281/zenodo.23376892); nothing else on Theorems A–D |
| OpenRefute (the-omega-institute/trureturing) | full text of the 938 problem files at commit 3a1bdf0 (14 October 2026) for 2609.09222, `Cayley graph`, `adjacency algebra`, `spectral algebra` | no entry for arXiv:2609.09222; its two entries by the same three authors concern a different preprint (arXiv:2610.02833, on union-closed families and sublattices) |

Conclusion: as of 20:05 UTC on 14 October 2026 we found no earlier statement of Theorems A–D and no
other answer to the questions of arXiv:2609.09222 that the paper settles.
